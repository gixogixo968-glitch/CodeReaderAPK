# Code Reader v11 — OPPO A16s / Android 11

هذه النسخة مبنية لتكون خفيفة على الهاتف مع الحفاظ على وظائف v10.

## الوظائف
- HTML / CSS / JavaScript في حقول مستقلة.
- فتح ملف منفرد ووضعه في الحقل الصحيح.
- استيراد ZIP واختيار ملفات HTML/CSS/JS تلقائيًا.
- عارض منفصل بملء الشاشة.
- تشغيل المعاينة عند الطلب فقط.
- شريط حالة وتقدم أثناء قراءة الملفات الكبيرة.
- قراءة الملفات الكبيرة على دفعات عندما تتجاوز 4MB لتقليل تجمد الواجهة.
- واجهة بسيطة مناسبة لشاشة 1600×720.

## ملاحظة مهمة للـ APK
ملف `jszip.min.js` موجود محليًا حتى لا يعتمد التطبيق على الإنترنت أثناء فتح ZIP.

## Android
عند تغليف المشروع داخل APK يمكن ربط `window.Android.openFile()` مع Android Storage Access Framework
(`ACTION_OPEN_DOCUMENT`) لإظهار منتقي ملفات النظام والتطبيقات المتاحة.

## حدود عملية
لا يوجد حد مصطنع للحجم، لكن أي ملف ضخم جدًا سيحتاج RAM لأن النص يجب أن يظهر داخل حقل التحرير.
على هاتف 4GB RAM يفضل تجنب فتح عدة ملفات ضخمة في الوقت نفسه.


v13: Based directly on the tested v11-oppo-a16s build. v11's existing chunked reader and ZIP/viewer behavior are preserved. Only a confirmation was added for files >= 50MB.
