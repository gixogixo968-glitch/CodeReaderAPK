(() => {
  "use strict";

  const fields = {
    html: document.getElementById("htmlCode"),
    css: document.getElementById("cssCode"),
    js: document.getElementById("jsCode")
  };

  const info = {
    html: document.getElementById("htmlInfo"),
    css: document.getElementById("cssInfo"),
    js: document.getElementById("jsInfo")
  };

  const state = { currentTab: "html", busy: false };

  const $ = id => document.getElementById(id);
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  function setStatus(msg) {
    $("status").textContent = msg;
  }

  function progress(show, percent = 0, text = "") {
    $("progressWrap").classList.toggle("hidden", !show);
    if (show) {
      $("progressBar").style.width = Math.max(0, Math.min(100, percent)) + "%";
      $("progressText").textContent = text || Math.round(percent) + "%";
    }
  }

  function fileKind(name) {
    const ext = (name.split(".").pop() || "").toLowerCase();
    if (ext === "html" || ext === "htm") return "html";
    if (ext === "css") return "css";
    if (ext === "js" || ext === "mjs" || ext === "cjs") return "js";
    return null;
  }

  function countLines(value) {
    if (!value) return 0;
    let count = 1;
    for (let i = 0; i < value.length; i++) if (value.charCodeAt(i) === 10) count++;
    return count;
  }

  function updateInfo(kind) {
    const value = fields[kind].value;
    const bytes = new Blob([value]).size;
    const mb = bytes / 1048576;
    info[kind].textContent = `${countLines(value).toLocaleString()} سطر • ${mb < 1 ? Math.round(bytes/1024) + " KB" : mb.toFixed(1) + " MB"}`;
  }

  Object.keys(fields).forEach(kind => {
    fields[kind].addEventListener("input", () => updateInfo(kind));
  });

  function showTab(kind) {
    state.currentTab = kind;
    document.querySelectorAll(".tab").forEach(b => b.classList.toggle("active", b.dataset.tab === kind));
    Object.keys(fields).forEach(k => $("panel-" + k).classList.toggle("active", k === kind));
  }

  document.querySelectorAll(".tab").forEach(b => b.addEventListener("click", () => showTab(b.dataset.tab)));

  async function readTextInChunks(file) {
    // File.text() is fast for small files, but chunked reading keeps the UI responsive for larger files.
    const size = file.size;
    if (size <= 4 * 1024 * 1024) {
      return await file.text();
    }

    const chunkSize = 1024 * 1024;
    const parts = [];
    let offset = 0;

    while (offset < size) {
      const end = Math.min(offset + chunkSize, size);
      const text = await file.slice(offset, end).text();
      parts.push(text);
      offset = end;
      const pct = (end / size) * 100;
      progress(true, pct, Math.round(pct) + "%");
      setStatus(`جارٍ قراءة ${file.name} — ${formatBytes(end)} من ${formatBytes(size)}`);
      await sleep(0);
    }
    return parts.join("");
  }

  function formatBytes(bytes) {
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1048576) return (bytes / 1024).toFixed(0) + " KB";
    return (bytes / 1048576).toFixed(1) + " MB";
  }

  async function putFile(file) {
    const kind = fileKind(file.name);
    if (!kind) {
      setStatus("هذا الملف ليس HTML أو CSS أو JavaScript.");
      return;
    }

    state.busy = true;
    try {
      if (file.size >= 50 * 1024 * 1024) {
        const ok = confirm(`حجم الملف ${formatBytes(file.size)}. قد يستهلك ذاكرة كبيرة على OPPO A16s. هل تريد المتابعة؟`);
        if (!ok) {
          state.busy = false;
          return;
        }
      }
      progress(true, 0, "0%");
      setStatus(`قراءة ${file.name}...`);
      const text = await readTextInChunks(file);
      fields[kind].value = text;
      updateInfo(kind);
      showTab(kind);
      setStatus(`تم فتح ${file.name} (${formatBytes(file.size)})`);
    } catch (err) {
      setStatus("تعذر قراءة الملف: " + (err?.message || err));
    } finally {
      progress(false);
      state.busy = false;
    }
  }

  $("fileBtn").addEventListener("click", () => {
    if (state.busy) return;
    if (window.Android && typeof window.Android.openFile === "function") {
      try { window.Android.openFile(); return; } catch (_) {}
    }
    $("fileInput").click();
  });

  $("fileInput").addEventListener("change", async e => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (file) await putFile(file);
  });

  function chooseEntry(entries, kind) {
    const candidates = entries.filter(x => fileKind(x.name) === kind);
    if (!candidates.length) return null;
    const base = candidates.map(x => ({x, n:x.name.replaceAll("\\","/").split("/").pop().toLowerCase()}));
    const preferred = kind === "html"
      ? ["index.html","index.htm"]
      : kind === "css"
      ? ["style.css","styles.css","main.css"]
      : ["app.js","main.js","script.js"];
    for (const p of preferred) {
      const hit = base.find(o => o.n === p);
      if (hit) return hit.x;
    }
    return candidates[0];
  }

  async function openZip(file) {
    if (!window.JSZip) {
      setStatus("مكتبة ZIP غير متوفرة.");
      return;
    }

    state.busy = true;
    try {
      fields.html.value = "";
      fields.css.value = "";
      fields.js.value = "";
      updateInfo("html"); updateInfo("css"); updateInfo("js");

      progress(true, 0, "0%");
      setStatus(`فتح ZIP: ${file.name}`);
      const zip = await JSZip.loadAsync(file, { createFolders: false });
      const entries = Object.values(zip.files).filter(e => !e.dir && fileKind(e.name));
      if (!entries.length) throw new Error("لم يتم العثور على HTML/CSS/JS داخل ZIP.");

      const kinds = ["html","css","js"];
      let done = 0;

      for (const kind of kinds) {
        const entry = chooseEntry(entries, kind);
        if (!entry) continue;

        setStatus(`استخراج ${entry.name}...`);
        // JSZip returns the selected text only once, then we assign it directly to its pane.
        const text = await entry.async("string");
        fields[kind].value = text;
        updateInfo(kind);
        done++;
        progress(true, (done / kinds.length) * 100, Math.round((done / kinds.length) * 100) + "%");
        await sleep(0);
      }

      showTab("html");
      setStatus(`تم استيراد ZIP — ${entries.length} ملف كود`);
    } catch (err) {
      setStatus("تعذر فتح ZIP: " + (err?.message || err));
    } finally {
      progress(false);
      state.busy = false;
    }
  }

  $("zipBtn").addEventListener("click", () => {
    if (!state.busy) $("zipInput").click();
  });

  // Android sends ZIP files selected through the system "Open with" chooser.
  window.receiveSharedZip = async function(name, base64) {
    try {
      const blob = new Blob([Uint8Array.from(atob(base64), c => c.charCodeAt(0))], {type: "application/zip"});
      const file = new File([blob], name || "shared.zip", {type: "application/zip"});
      await openZip(file);
    } catch (err) {
      setStatus("تعذر فتح ZIP القادم من تطبيق آخر: " + (err?.message || err));
    }
  };

  $("zipInput").addEventListener("change", async e => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (file) await openZip(file);
  });

  function getCode() {
    return {
      html: fields.html.value,
      css: fields.css.value,
      js: fields.js.value
    };
  }

  function buildDocument() {
    const {html, css, js} = getCode();
    let doc = html || "<!doctype html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"></head><body></body></html>";

    if (css) {
      const styleTag = `<style>\n${css}\n</style>`;
      if (/<\/head\s*>/i.test(doc)) doc = doc.replace(/<\/head\s*>/i, styleTag + "\n</head>");
      else doc = styleTag + "\n" + doc;
    }

    if (js) {
      const scriptTag = `<script>\n${js}\n<\/script>`;
      if (/<\/body\s*>/i.test(doc)) doc = doc.replace(/<\/body\s*>/i, scriptTag + "\n</body>");
      else doc += "\n" + scriptTag;
    }

    return doc;
  }

  function renderPreview() {
    $("previewFrame").srcdoc = buildDocument();
  }

  function openViewer() {
    renderPreview();
    $("codesScreen").classList.remove("active");
    $("previewScreen").classList.add("active");
    $("codesNavBtn").classList.remove("active");
    $("previewNavBtn").classList.add("active");
  }

  function openCodes() {
    $("previewScreen").classList.remove("active");
    $("codesScreen").classList.add("active");
    $("previewNavBtn").classList.remove("active");
    $("codesNavBtn").classList.add("active");
  }

  $("runBtn").addEventListener("click", openViewer);
  $("previewNavBtn").addEventListener("click", openViewer);
  $("backBtn").addEventListener("click", openCodes);
  $("codesNavBtn").addEventListener("click", openCodes);
  $("refreshBtn").addEventListener("click", renderPreview);

  // Android APK bridge: the native wrapper can call this after ACTION_OPEN_DOCUMENT.
  window.CodeReader = {
    putText(kind, text, name = "") {
      if (!fields[kind]) return;
      fields[kind].value = text || "";
      updateInfo(kind);
      showTab(kind);
      setStatus(name ? `تم فتح ${name}` : "تم فتح الملف");
    },
    putTexts(data) {
      for (const kind of ["html","css","js"]) {
        if (typeof data?.[kind] === "string") {
          fields[kind].value = data[kind];
          updateInfo(kind);
        }
      }
      showTab("html");
      setStatus("تم استيراد الملفات");
    }
  };

  updateInfo("html"); updateInfo("css"); updateInfo("js");
  showTab("html");
})();
