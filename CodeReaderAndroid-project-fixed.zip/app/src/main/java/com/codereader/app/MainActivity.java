package com.codereader.app;

import android.app.Activity;
import android.os.Bundle;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.content.ContentResolver;
import android.util.Base64;
import android.database.Cursor;
import android.provider.OpenableColumns;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class MainActivity extends Activity {
    private WebView webView;
    private Uri pendingZip;
    private String pendingName = "shared.zip";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.addJavascriptInterface(new Bridge(), "Android");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                deliverPendingZip();
            }
        });
        handleIntent(getIntent());
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
        deliverPendingZip();
    }

    private void handleIntent(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        Uri uri = intent.getData();
        if (Intent.ACTION_VIEW.equals(action) && uri != null) {
            pendingZip = uri;
            pendingName = queryName(uri);
        }
    }

    private String queryName(Uri uri) {
        Cursor c = null;
        try {
            c = getContentResolver().query(uri, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) return c.getString(idx);
            }
        } catch (Exception ignored) { } finally { if (c != null) c.close(); }
        return "shared.zip";
    }

    private void deliverPendingZip() {
        if (pendingZip == null || webView == null) return;
        final Uri uri = pendingZip;
        final String name = pendingName;
        pendingZip = null;
        new Thread(() -> {
            try {
                InputStream in = getContentResolver().openInputStream(uri);
                if (in == null) throw new IOException("Cannot open ZIP");
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buffer = new byte[8192];
                int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                in.close();
                String b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
                String safeName = name.replace("\\", "\\\\").replace("'", "\\'");
                final String js = "window.receiveSharedZip && window.receiveSharedZip('" + safeName + "','" + b64 + "')";
                runOnUiThread(() -> webView.evaluateJavascript(js, null));
            } catch (Exception e) {
                final String msg = e.getMessage() == null ? "تعذر قراءة الملف" : e.getMessage();
                runOnUiThread(() -> webView.evaluateJavascript("document.getElementById('status').textContent='تعذر فتح ZIP من التطبيقات الأخرى';", null));
            }
        }).start();
    }

    public class Bridge {
        @JavascriptInterface public void closeApp() { runOnUiThread(() -> finish()); }
    }
}