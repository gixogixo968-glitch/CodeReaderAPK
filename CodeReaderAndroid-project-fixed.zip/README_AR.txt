Code Reader Android — تعليمات مختصرة

هذا أرشيف مشروع Android كامل، وليس ملف APK جاهزًا.

محتوياته:
- ملفات واجهة Code Reader الأصلية داخل app/src/main/assets/
- أيقونة التطبيق داخل موارد Android
- AndroidManifest لاستقبال ZIP من التطبيقات الأخرى
- GitHub Actions لبناء APK تلقائيًا

مهم: GitHub لا يفك ZIP تلقائيًا عند رفعه. يجب استخراج محتويات هذا الأرشيف ثم رفع ملفات ومجلدات المشروع إلى جذر المستودع، بحيث يظهر مجلد .github وملف settings.gradle ومجلد app مباشرة في المستودع. بعد الرفع افتح Actions وشغّل Build Android APK أو انتظر البناء التلقائي.

لم يتم تأكيد نجاح البناء حتى الآن؛ يجب مراجعة نتيجة GitHub Actions.
